package kaaes.spotify.webapi.android.models;

public class AlbumsPager {
    public Pager<AlbumSimple> albums;
}
