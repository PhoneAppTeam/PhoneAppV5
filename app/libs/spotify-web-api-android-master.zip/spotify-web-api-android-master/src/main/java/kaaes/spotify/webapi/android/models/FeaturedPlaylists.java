package kaaes.spotify.webapi.android.models;

public class FeaturedPlaylists {
    public String message;
    public Pager<PlaylistSimple> playlists;
}
