package kaaes.spotify.webapi.android.models;

public class ErrorResponse {
    public ErrorDetails error;
}
