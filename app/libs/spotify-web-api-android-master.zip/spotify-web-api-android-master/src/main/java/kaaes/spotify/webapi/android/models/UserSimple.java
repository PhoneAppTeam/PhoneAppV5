package kaaes.spotify.webapi.android.models;

import java.util.Map;

public class UserSimple {
    public Map<String, String> external_urls;
    public String href;
    public String id;
    public String type;
    public String uri;
}
