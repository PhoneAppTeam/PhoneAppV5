package kaaes.spotify.webapi.android.models;

public class TracksPager {
    public Pager<Track> tracks;
}
