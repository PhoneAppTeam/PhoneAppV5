package kaaes.spotify.webapi.android.models;

public class ArtistsPager {
    public Pager<Artist> artists;
}
