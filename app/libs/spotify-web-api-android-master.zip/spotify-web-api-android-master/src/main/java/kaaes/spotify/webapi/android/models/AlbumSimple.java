package kaaes.spotify.webapi.android.models;

import java.util.List;
import java.util.Map;

public class AlbumSimple {
    public String album_type;
    public List<String> available_markets;
    public Map<String, String> external_urls;
    public String href;
    public String id;
    public List<Image> images;
    public String name;
    public String type;
    public String uri;
}
