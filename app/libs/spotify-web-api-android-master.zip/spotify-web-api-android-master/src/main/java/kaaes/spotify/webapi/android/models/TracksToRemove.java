package kaaes.spotify.webapi.android.models;

import java.util.List;

public class TracksToRemove {
    public List<TrackToRemove> tracks;
}
