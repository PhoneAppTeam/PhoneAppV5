package kaaes.spotify.webapi.android.models;

import java.util.List;

public class Albums {
    public List<Album> albums;
}
