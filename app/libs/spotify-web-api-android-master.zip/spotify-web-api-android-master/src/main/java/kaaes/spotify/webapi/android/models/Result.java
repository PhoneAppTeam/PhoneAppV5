package kaaes.spotify.webapi.android.models;

public class Result {
}
