package kaaes.spotify.webapi.android.models;

import java.util.List;

public class TracksToRemoveWithPosition {
    public List<TrackToRemoveWithPosition> tracks;
}
