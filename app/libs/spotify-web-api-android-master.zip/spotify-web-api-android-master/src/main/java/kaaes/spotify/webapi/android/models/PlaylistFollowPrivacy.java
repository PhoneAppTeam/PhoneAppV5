package kaaes.spotify.webapi.android.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PlaylistFollowPrivacy {
    @SerializedName("public")
    public Boolean is_public;
}
